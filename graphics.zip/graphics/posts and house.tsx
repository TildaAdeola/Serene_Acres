<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="posts and house" tilewidth="64" tileheight="80" tilecount="10" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="16" height="16" source="full version/tiles/posttlc.png"/>
 </tile>
 <tile id="1">
  <image width="16" height="16" source="full version/tiles/postblc.png"/>
 </tile>
 <tile id="2">
  <image width="16" height="16" source="full version/tiles/postbrc.png"/>
 </tile>
 <tile id="3">
  <image width="16" height="16" source="full version/tiles/postls.png"/>
 </tile>
 <tile id="4">
  <image width="16" height="16" source="full version/tiles/posttop.png"/>
 </tile>
 <tile id="5">
  <image width="16" height="16" source="full version/tiles/posttrc.png"/>
 </tile>
 <tile id="6">
  <image width="32" height="16" source="full version/tiles/bench.png"/>
 </tile>
 <tile id="7">
  <image width="64" height="80" source="full version/Buildings/gifs/player house/house_player.gif"/>
 </tile>
 <tile id="9">
  <image width="16" height="32" source="../../../Computer science/Project/full version/tiles/Scarecrow.png"/>
 </tile>
 <tile id="10" x="0" y="0" width="16" height="16">
  <image width="80" height="80" source="../../../Computer science/Project/full version/cookingthing.png"/>
 </tile>
</tileset>
