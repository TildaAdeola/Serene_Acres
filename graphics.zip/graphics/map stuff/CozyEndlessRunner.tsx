<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="CozyEndlessRunner" tilewidth="16" tileheight="16" tilecount="10508" columns="148">
 <image source="global.png" width="2368" height="1136"/>
</tileset>
